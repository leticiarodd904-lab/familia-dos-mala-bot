# Família dos Mala — Bot Discord

Bot multifuncional em Node.js + discord.js v14.

## Comandos incluídos

### Utilidade
- `/ping`
- `/ajuda`
- `/serverinfo`
- `/userinfo`
- `/avatar`
- `/emoji`

### Moderação
- `/clear`
- `/kick`
- `/ban`
- `/unban`
- `/timeout`
- `/lock`
- `/unlock`
- `/slowmode`

### Administração
- `/anuncio`
- `/say`
- `/cargo dar`
- `/cargo tirar`

## Entrada automática

O bot pode:
- dar um cargo automaticamente a novos membros (`AUTO_ROLE_ID`);
- mandar mensagem de boas-vindas (`WELCOME_CHANNEL_ID`);
- mandar mensagem quando alguém sair (`GOODBYE_CHANNEL_ID`).

### Importante sobre "aprovar quem entra"

Um bot pode automatizar cargo e boas-vindas depois que a pessoa entra. Ele não pode simplesmente aceitar por conta própria uma solicitação de entrada que esteja aguardando aprovação do servidor quando o próprio Discord exige uma ação de membro/admin.

## Configuração

1. Instale Node.js 20 ou superior.
2. Copie `.env.example` para `.env`.
3. Preencha o token do bot, Client ID e ID do servidor.
4. Rode:
   npm install
   npm start

Nunca publique o token do bot no GitHub. Se o token for exposto, gere outro no Discord Developer Portal.

## Hospedagem

A Vercel usada para o site não é a hospedagem ideal para manter este processo do bot ligado 24 horas. Para o bot, use uma hospedagem de processo Node.js compatível.
