# Família dos Mala — versão para hospedagem gratuita

Esta versão foi preparada para rodar como um Web Service Node.js em uma hospedagem com plano gratuito, usando o Koyeb.

## Arquivos principais
- `index.js` — bot
- `package.json` — dependências e `npm start`
- `Procfile` — comando de inicialização
- `.env.example` — variáveis necessárias

## Configuração
Use estas variáveis no painel da hospedagem:
- `DISCORD_TOKEN`
- `CLIENT_ID`
- `GUILD_ID`

Opcionais:
- `WELCOME_CHANNEL_ID`
- `GOODBYE_CHANNEL_ID`
- `AUTO_ROLE_ID`

Nunca coloque o token do Discord no GitHub ou dentro deste ZIP.

## Configuração do serviço
- Builder: Buildpack
- Language: Node.js
- Build command: `npm install`
- Run/Start command: `npm start`
- Port: `3000` (ou a porta `PORT` fornecida pela hospedagem)

O bot também inicia um pequeno servidor HTTP de saúde para ser aceito como Web Service.
